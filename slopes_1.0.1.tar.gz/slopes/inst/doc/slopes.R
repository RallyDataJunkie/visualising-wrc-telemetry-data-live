## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# # install.packages("remotes")
# remotes::install_github("ropensci/slopes")

## ----eval=FALSE---------------------------------------------------------------
# # install.packages("remotes")
# remotes::install_github("ropensci/slopes", dependencies = "Suggests")

## ----eval=FALSE---------------------------------------------------------------
# usethis::edit_r_environ()
# MAPBOX_API_KEY=xxxxx # replace XXX with your api key

## ----message=FALSE, warning=FALSE---------------------------------------------
library(slopes)
library(sf)

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# m = st_coordinates(sf::st_transform(lisbon_road_segment, 4326))
# s = seq(from = 1, to = nrow(m), length.out = 4)
# round(m[s, 1:2], 5)
# dput(round(m[s, 1], 4))
# dput(round(m[s, 2], 4))

## -----------------------------------------------------------------------------
m = cbind(
  c(-9.1333, -9.134, -9.13),
  c(38.714, 38.712, 38.710)
)
sf_linestring = sf::st_sf(
  data.frame(id = 1),
  geometry = st_sfc(st_linestring(m)),
  crs = 4326
)
class(sf_linestring)
st_geometry_type(sf_linestring)

## -----------------------------------------------------------------------------
sf_linestring = lisbon_road_segment
class(sf_linestring)
st_geometry_type(sf_linestring)

## ----linestringmap, message=FALSE, warning=FALSE------------------------------
library(tmap)
tmap_mode("view")
tm_shape(sf_linestring) +
  tm_lines(lwd = 5) +
  tm_basemap(leaflet::providers$Esri.WorldTopoMap)

## ----eval=FALSE---------------------------------------------------------------
# sf_linestring_xyz = elevation_add(sf_linestring) # dem = NULL
# #> Loading required namespace: ceramic
# #> Preparing to download: 9 tiles at zoom = 18 from
# #> https://api.mapbox.com/v4/mapbox.terrain-rgb/

## ----echo=FALSE---------------------------------------------------------------
# note: the following should be TRUE
# identical(sf_linestring_xyz, lisbon_road_segment_xyz_mapbox)
sf_linestring_xyz = lisbon_road_segment_xyz_mapbox

## -----------------------------------------------------------------------------
st_coordinates(sf_linestring_xyz)

## -----------------------------------------------------------------------------
z_value(sf_linestring_xyz) # returns all the elevation values between xy coordinates

z_mean(sf_linestring_xyz) # elevation mean value
z_min(sf_linestring_xyz) # elevation min value 
z_max(sf_linestring_xyz) # elevation max value 
z_start(sf_linestring_xyz) # first z
z_end(sf_linestring_xyz) # last z

## -----------------------------------------------------------------------------
slope_xyz(sf_linestring_xyz)

## ----message=FALSE, warning=FALSE---------------------------------------------
sf_route = lisbon_route
class(sf_route)
st_geometry_type(sf_route)

tm_shape(sf_route) +
  tm_lines(lwd = 3) +
  tm_basemap(leaflet::providers$Esri.WorldTopoMap)

## ----eval=FALSE---------------------------------------------------------------
# sf_route_xyz = elevation_add(sf_route)
# #> Loading required namespace: ceramic
# #> Preparing to download: 12 tiles at zoom = 15 from
# #> https://api.mapbox.com/v4/mapbox.terrain-rgb/

## ----echo=FALSE---------------------------------------------------------------
# note: the following should be TRUE
# identical(sf_route_xyz, lisbon_road_segment_xyz_mapbox)
sf_route_xyz = lisbon_route_xyz_mapbox

## -----------------------------------------------------------------------------
slope_xyz(sf_route_xyz)

## -----------------------------------------------------------------------------
class(dem_lisbon_raster)
slope_raster(routes = sf_route,
             dem = dem_lisbon_raster)

## ----eval=FALSE, include=FALSE------------------------------------------------
# #not to use like this... it would ge good to have a gps example to demonstrate
# 
# slope_vector(sf_route_xyz)
# slope_distance(sf_route_xyz)
# slope_distance_mean(sf_route_xyz)
# slope_distance_weighted(sf_route_xyz)
# 
# slope_vector(sf_linestring_xyz)
# slope_distance(sf_linestring_xyz)
# slope_distance_mean(sf_linestring_xyz)
# slope_distance_weighted(sf_linestring_xyz)

## -----------------------------------------------------------------------------
# for a line xz
x = c(0, 2, 3, 4, 5, 9)
elevations = c(1, 2, 2, 4, 3, 1) / 10
slope_vector(x, elevations)

# for a path xyz
xy = st_coordinates(sf_linestring)
dist = sequential_dist(xy, lonlat = FALSE)
elevations = elevation_extract(xy, dem_lisbon_raster)

slope_distance(dist, elevations)
slope_distance_mean(dist, elevations)
slope_distance_weighted(dist, elevations)

## ----dem-lisbon---------------------------------------------------------------
# A raster dataset included in the package:
class(dem_lisbon_raster) # digital elevation model
summary(raster::values(dem_lisbon_raster)) # heights range from 0 to ~100m
raster::plot(dem_lisbon_raster)

# A vector dataset included in the package:
class(lisbon_road_network)
plot(sf::st_geometry(lisbon_road_network), add = TRUE)

## -----------------------------------------------------------------------------
lisbon_road_network$slope = slope_raster(lisbon_road_network, dem = dem_lisbon_raster)
summary(lisbon_road_network$slope)

## -----------------------------------------------------------------------------
cor(
  lisbon_road_network$slope,    # slopes calculates by the slopes package
  lisbon_road_network$Avg_Slope # slopes calculated by ArcMap's 3D Analyst extension
)

## ----slope-vis----------------------------------------------------------------
raster::plot(dem_lisbon_raster)
plot(lisbon_road_network["slope"], add = TRUE, lwd = 5)

## ----route--------------------------------------------------------------------
# library(tmap)
# tmap_mode("view")
qtm(lisbon_route)

## ----echo=FALSE, eval=FALSE---------------------------------------------------
# # Removed because it's not rendering in RMarkdown
# mapview::mapview(lisbon_road_network["slope"], map.types = "Esri.WorldStreetMap")
# mapview::mapview(lisbon_route)

## ----eval=TRUE----------------------------------------------------------------
lisbon_route_xyz = elevation_add(lisbon_route, dem_lisbon_raster) 

## ----plot_slope---------------------------------------------------------------
plot_slope(lisbon_route_xyz)

## -----------------------------------------------------------------------------
sf::st_length(lisbon_route_xyz) # check route length: 2.5 km
lisbon_route_segments = stplanr::rnet_breakup_vertices(lisbon_route_xyz)
summary(sf::st_length(lisbon_route_segments)) # mean of 50 m

## -----------------------------------------------------------------------------
lisbon_route_segments$slope = slope_xyz(lisbon_route_segments)
summary(lisbon_route_segments$slope)

## -----------------------------------------------------------------------------
lisbon_route_segments$slope_directed = slope_xyz(lisbon_route_segments, directed = TRUE)
summary(lisbon_route_segments$slope_directed)

## ----fig.show='hold', out.width="50%"-----------------------------------------
breaks = c(0, 3, 5, 8, 10, 20, 50)
breaks_proportion = breaks / 100
breaks_directed = c(-rev(breaks_proportion), (breaks_proportion[-1]))
plot(lisbon_route_segments["slope"], breaks = breaks_proportion)
plot(lisbon_route_segments["slope_directed"], breaks = breaks_directed)

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# # test code
# z = sf::st_make_grid(lisbon_route_xyz, cellsize = 100)
# sampled_points = sf::st_line_sample(lisbon_route_xyz, n = 30)
# points_sf = sf::st_sf(geometry = sf::st_cast(sampled_points, "POINT"))
# plot(points_sf)
# lisbon_route_segments = stplanr::route_split(lisbon_route_xyz, p = points_sf[2:3, ])
# lisbon_route_segments = stplanr::rnet_breakup_vertices(lisbon_route_xyz)
# library(tmap)
# tmap_mode("view")
# qtm(lisbon_route_segments, lines.lwd = 9, lines.col = 1:nrow(lisbon_route_segments))
# plot(lisbon_route_segments, col = 1:nrow(lisbon_route_segments))

## ----eval=FALSE, echo=FALSE---------------------------------------------------
# # Test: try using QGIS
# remotes::install_github("paleolimbot/qgisprocess")
# library(qgisprocess)
# qgis_configure()
# algorithms = qgis_algorithms()
# View(algorithms)
# result = qgis_run_algorithm(
#   algorithm = "grass7:v.split",
#   INPUT = lisbon_route_xyz,
#   LENGTH = 500
#   )
# route_segments = sf::st_read(result$OUTPUT)
# route_segments
# plot(lisbon_route_xyz$geometry)
# plot(route_segments$geom, add = T, lwd = 3)
# mapview::mapview(route_segments)

## ----message=FALSE, warning=FALSE, eval=FALSE---------------------------------
# dem_mapbox = elevation_get(lisbon_route)
# lisbon_road_proj = st_transform(lisbon_route, raster::crs(dem_mapbox))
# lisbon_route_xyz_mapbox = elevation_add(lisbon_road_proj, dem = dem_mapbox)
# plot_slope(lisbon_route_xyz_mapbox)

## ----eval=FALSE---------------------------------------------------------------
# lisbon_route_xyz_auto = elevation_add(lisbon_route) #dem = NULL

## ----echo=FALSE---------------------------------------------------------------
lisbon_route_xyz_auto = lisbon_route_xyz_mapbox

## -----------------------------------------------------------------------------
plot_slope(lisbon_route_xyz_auto)

## ----eval=FALSE---------------------------------------------------------------
# cyclestreets_xyz = elevation_add(cyclestreets_route)
# plot_slope(cyclestreets_xyz)
# plot(cumsum(cyclestreets_xyz$distances), cumsum(cyclestreets_xyz$elevation_change))

