library(testthat)
library(slopes)

test_check("slopes")
