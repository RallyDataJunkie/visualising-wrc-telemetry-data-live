# slopes 1.0.1

* Package source code now hosted at https://github.com/ropensci/slopes
* New documentation section showing how directed routes work: https://docs.ropensci.org/slopes/articles/slopes.html#splitting-the-network

# slopes 1.0.0

* We have submitted and responded to all comments to [rOpenSci review](https://github.com/ropensci/software-review/issues/420).  
* Many changes, including breaking changes to function names.  
* Added a `NEWS.md` file to track changes to the package.  


# slopes 0.0.1

* Initial version of the package on GitHub.  
